<!DOCTYPE html>
<html lang="en">
<head>
<title>Synergy</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Unicat project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="plugins/video-js/video-js.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="styles/blog.css">
<link rel="stylesheet" type="text/css" href="styles/blog_responsive.css">
</head>
<body>

<div class="super_container">

	<!-- Header -->

	<header class="header">
			<!-- Top Bar -->
		<div class="top_bar">
			<div class="top_bar_container" style="background-color: #cc9a5e">
				<div class="container">
					<div class="row">
						<div class="col">
							<div class="top_bar_content d-flex flex-row align-items-center justify-content-start">
								<ul class="top_bar_contact_list">
									<li><div class="question">Have any questions?</div></li>
									<li>
										<i class="fa fa-phone" aria-hidden="true"></i>
										<div>+91 9322040870</div>
                                        <div> | +91 8369720901</div>
									</li>
									<li>
										<i class="fa fa-envelope-o" aria-hidden="true"></i>
										<div>synergy.aos@gmail.com</div>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>				
		</div>

		<!-- Header Content -->
	
		
		<div class="header_container" style="background-color: #292929">
			<div class="container-fluid">
				<div class="row">
					<div class="col">
						<div class="header_content d-flex flex-row align-items-center justify-content-start">
							<div class="logo_container">
								<a href="#">
									<div class="logo_text" style="color: white">S<span style="color:#d8731a">y</span>nerg<span style="color: #d8731a">y</span></div>
									<br>
									<br>
									<h5 style="color: white">Academy of Science</h5>
								</a>
							</div>
							<nav class="main_nav_contaner ml-auto">
								<ul class="main_nav">
									<li><a href="index.php" style="color: white">Home</a></li>
									<li><a href="about.php" style="color: white">About Us</a></li>
									<li><a href="courses.php" style="color: white">Courses</a></li>
									<li><a href="gallery.php" style="color: white">Image Gallery</a></li>
									<li><a href="contact.php" style="color: white">Contact Us</a></li>
									<li><a href="#notices" style="color: white">Notices  <sup> <blink><img src="images/new.png" height="40px;" width="50px;" alt="new"></blink></sup></a></li>
									<li><a href="faq.php" style="color: white">FAQ</a></li>
									<li>
								<div class="top_bar_login ml-auto">
									<div class="login_button"><a href="identity.php">Login</a></div>
								</div>
								</li>
								</ul>

								
								<div class="hamburger menu_mm">
									<i class="fa fa-bars menu_mm" aria-hidden="true"></i>
								</div>
							</nav>

						</div>
					</div>
				</div>
			</div>
		</div>
	</header>


	<!-- Menu -->

	<div class="menu d-flex flex-column align-items-end justify-content-start text-right menu_mm trans_400">
		<div class="menu_close_container"><div class="menu_close"><div></div><div></div></div></div>
		<div class="search">
			<form action="#" class="header_search_form menu_mm">
				<input type="search" class="search_input menu_mm" placeholder="Search" required="required">
				<button class="header_search_button d-flex flex-column align-items-center justify-content-center menu_mm">
					<i class="fa fa-search menu_mm" aria-hidden="true"></i>
				</button>
			</form>
		</div>
		<nav class="menu_nav">
			<ul class="menu_mm">
				<li class="menu_mm"><a href="index.html">Home</a></li>
				<li class="menu_mm"><a href="#">About</a></li>
				<li class="menu_mm"><a href="#">Courses</a></li>
				<li class="menu_mm"><a href="#">Blog</a></li>
				<li class="menu_mm"><a href="#">Page</a></li>
				<li class="menu_mm"><a href="contact.html">Contact</a></li>
			</ul>
		</nav>
	</div>
	
	<!-- Home -->

	<div class="home">
		<div class="breadcrumbs_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="breadcrumbs">
							<ul>
								<li><a href="index.php">Home</a></li>
								<li>courses</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>			
	</div>

	<!-- Blog -->

	<div class="blog">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="blog_post_container">

						<!-- Blog Post -->
						<div class="blog_post trans_200">
							<div class="blog_post_image"><img src="images/jeemain.png" alt=""></div>
							<div class="blog_post_body">
								<div class="blog_post_title"><a href="">JEE Main coaching</a></div>
								<div class="blog_post_meta">
									<ul>
										<li><a href="#">admin</a></li>
										<li><a href="#">november 11, 2017</a></li>
									</ul>
								</div>
								<div class="blog_post_text">
									<p>Joint Entrance Exam (JEE) Main is the national level undergraduate engineering entrance exam conducted by National Testing Agency for admission to B.Tech/B.E. programmes in 31 NITs, 23 IIITs and 23 CFTIs.</p>
								</div>
							</div>
						</div>

						<!-- Blog Post -->
						<div class="blog_post trans_200">
							<div class="blog_post_body">
								<div class="blog_post_title"><a href="">With Changing Students and Times</a></div>
								<div class="blog_post_meta">
									<ul>
										<li><a href="#">admin</a></li>
										<li><a href="#">november 11, 2017</a></li>
									</ul>
								</div>
								<div class="blog_post_text">
									<p>Policy analysts generally agree on a need for reform, but not on which path policymakers should take...</p>
								</div>
							</div>
						</div>

						<!-- Blog Post -->
						<div class="blog_post trans_200">
						<div class="blog_post_image"><img src="images/jeeadvance.png" alt=""></div>
							<div class="blog_post_body">
								<div class="blog_post_title"><a href="">JEE Advanced coaching</a></div>
								<div class="blog_post_meta">
									<ul>
										<li><a href="#">admin</a></li>
										<li><a href="#">november 11, 2017</a></li>
									</ul>
								</div>
								<div class="blog_post_text">
									<p>Joint Entrance Examination Advanced (JEE Advanced) is a national level engineering entrance exam conducted by seven zonal Indian Institutes of Technology (IITs) under the guidance of Joint Admission Board (JAB) every year, for admissions to 23 Indian Institutes of Technology (IITs).</p>
								</div>
							</div>
						</div>

						<!-- Blog Post -->
						<div class="blog_post trans_200">
							<div class="blog_post_image"><img src="images/blog_3.jpg" alt=""></div>
							<div class="blog_post_body">
								<div class="blog_post_title"><a href="blog_single.html">NEET coaching</a></div>
								<div class="blog_post_meta">
									<ul>
										<li><a href="#">admin</a></li>
										<li><a href="#">november 11, 2017</a></li>
									</ul>
								</div>
								<div class="blog_post_text">
									<p>The National Eligibility cum Entrance Test (UG) is a new qualifying cum entrance examination notified under the 'Regulations on Graduate Medical Education 1997 and BDS Course Regulations, 2007' by the Medical Council of India as published in the Gazette of India Extraordinary dated 21st December, 2010 and 15st February, 2012 and the Dental Council of India as published in the Gazette of India Extraordinary dated 31st May, 2012. NEET has been introduced by Ministry of Human Resource Development (MHRD) Govt, of India and Medical Council of India (MCI).</p>
								</div>
							</div>
						</div>

						<!-- Blog Post -->
						<div class="blog_post trans_200">
						<div class="blog_post_image"><img src="images/olympiad.png" alt=""></div>
							<div class="blog_post_body">
								<div class="blog_post_title"><a href="">Olympiads</a></div>
								<div class="blog_post_meta">
									<ul>
										<li><a href="#">admin</a></li>
										<li><a href="#">november 11, 2017</a></li>
									</ul>
								</div>
								<div class="blog_post_text">
									<p>Olympiads are the exams which are conducted at a very large scale for students from class 2 to 12. Giving exams at all India level or state level helps the student to analyse his or her weak and strong points. Moreover this helps the students to figure out their position among the other. The ranks provided act as an advantage for them. They help to motivate students to strive for better and deeper understanding of scientific facts and data and to enhance their reasoning, analytical and problem solving skills There are various exams which are conducted all over India.</p>
								</div>
							</div>
						</div>

						<!-- Blog Post -->
						<div class="blog_post trans_200">
							<div class="blog_post_image"><img src="images/boards.png" alt=""></div>
							<div class="blog_post_body">
								<div class="blog_post_title"><a href="">State & CBSE boards coaching</a></div>
								<div class="blog_post_meta">
									<ul>
										<li><a href="#">admin</a></li>
										<li><a href="#">november 11, 2017</a></li>
									</ul>
								</div>
								<div class="blog_post_text">
									<p>In India, board examinations refer to the public examinations that occur at the end of the 10th grade education (SSLC), or at the end of the 12th grade education (HSC). The scores achieved in these exams are considered very important for getting into universities, professional courses or training programmes, and even possibly in finding employment</p>
								</div>
							</div>
						</div>


					</div>
				</div>
			</div>
			<div class="row">
				
			</div>
		</div>
	</div>

	

	

	<!-- Footer -->

	<footer class="footer" style="background-color: #141313">
		<div class="footer_background" style="background-image:url(images/footer_background.png)"></div>
		<div class="container">
			<div class="row footer_row">
				<div class="col">
					<div class="footer_content">
						<div class="row">

							<div class="col-lg-3 footer_col">
					
								<!-- Footer About -->
								<div class="footer_section footer_about">
									<div class="footer_logo_container">
										<a href="#">
											<div class="footer_logo_text">S<span style="color: #d8731a">y</span>nerg<span style="color: #d8731a">y</span></div>
											<br>
											<h4 style="color: white">Academy of Science</h4>
										</a>
									</div>
									<div class="footer_about_text">
										<p>IIT-JEE | Medical | CBSE Board | Olympiad</p>
									</div>
									<div class="footer_social">
										<ul>
											<li><a href="https://www.facebook.com/synergyacademyofscience/"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
											<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
											<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
										</ul>
									</div>
								</div>
								
							</div>

							<div class="col-lg-3 footer_col">
					
								<!-- Footer Contact -->
								<div class="footer_section footer_contact">
									<div class="footer_title" style="color: #d8731a">Contact Us</div>
									<div class="footer_contact_info">
										<ul>
											<li>Email: synergy.aos@gmail.com</li>
											<li>Phone:  +91 9322040870 | +91 8369720901</li>
											<li>Shop No. 16, Chaturbhuj Society, Shilp Chowk, Sector 21, Kharghar, Navi Mumbai - 410210, Next to IDBI Bank</li>
										</ul>
									</div>
								</div>
								
							</div>

							<div class="col-lg-3 footer_col">
					
								
							</div>

							<div class="col-lg-3 footer_col clearfix">
					
								
							</div>

						</div>
					</div>
				</div>
			</div>

			<div class="row copyright_row">
				<div class="col">
					<div class="cr_text" style="padding: 20px 0px;">
Copyright &copy; All rights reserved | This website is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="#">ELIT</a>
</div>
<!--
						<div class="ml-lg-auto cr_links">
							<ul class="cr_list" style="float: right;">
								<li><a href="#">Copyright notification</a></li>
								<li><a href="#">Terms of Use</a></li>
								<li><a href="#">made with love by elit</a></li>
							</ul>
						</div>
-->
				</div>
			</div>
		</div>
	</footer>
</div>
<script type="text/javascript">
      function blink() {
        var blinks = document.getElementsByTagName('blink');
        for (var i = blinks.length - 1; i >= 0; i--) {
          var s = blinks[i];
          s.style.visibility = (s.style.visibility === 'visible') ? 'hidden' : 'visible';
        }
        window.setTimeout(blink, 500);
      }
      if (document.addEventListener) document.addEventListener("DOMContentLoaded", blink, false);
      else if (window.addEventListener) window.addEventListener("load", blink, false);
      else if (window.attachEvent) window.attachEvent("onload", blink);
      else window.onload = blink;
</script>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/masonry/masonry.js"></script>
<script src="plugins/video-js/video.min.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="js/blog.js"></script>
</body>
</html>