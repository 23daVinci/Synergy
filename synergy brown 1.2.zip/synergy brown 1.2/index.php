<?php include "includes/enroll.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Synergy</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Unicat project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="styles/main_styles.css">
<link rel="stylesheet" type="text/css" href="styles/responsive.css">
<style>
    .awNotices {
  position: relative;
  color: white;
  font: 400 12px Arial;
}
.awNotices a {
  padding: 8px 25px 8px 10px;
  position: absolute;
  left: 0;
  right: 0;
  opacity: 0;
  color: inherit;
  text-decoration: none;
  visibility: hidden;
  transition: opacity .6s;
  border-radius: 3px;
  text-shadow: 0 0 3px rgba(1, 1, 1, 0.3);
  line-height: 150%;
}
.li{
        color: white;
    }
.awNotices a i.fa {
  padding-right: 8px;
  margin-right: 5px;
  border-right: 1px solid rgba(255, 255, 255, 0.2);
}
.awNotices a[notice-color="orange"] {
  background-color: #ff9800;
}
.awNotices a[notice-color="red"] {
  background-color: #e51c23;
}
.awNotices a[notice-color="blue"] {
  background-color: #3f51b5;
}
.awNotices a[notice-color="green"] {
  background-color: #8bc34a;
}
.awNotices a[notice-color="dark"] {
  background-color: #414141;
}
.awNotices a.active {
  opacity: 1;
  visibility: visible;
}
.awNotices span.controller {
  position: absolute;
  cursor: pointer;
  background: transparent;
  right: 0;
  padding: 8px 10px;
  line-height: 150%;
}

</style>
</head>
<body>
<section class="awNotices">
  <a href="http://adobewordpress.com" notice-color="orange"><i class="fa fa-bell"></i>‘Tomorrowland’ Is a Box-Office Disappointment</a>
  <a notice-color="red"><i class="fa fa-heart"></i>Sunday Book Review: Shakespeare in Love</a>
  <a notice-color="blue"><i class="fa fa-desktop"></i>Overvalued in Silicon Valley, but Don’t Say ‘Tech Bubble’</a>
  <a notice-color="green"><i class="fa fa-leaf"></i>Emergency Fund Created for World Health Agency</a>
  <a notice-color="dark"><i class="fa fa-comments"></i>John Nash, Nobel Winner, Dies in Crash.</a>
</section>

<div class="super_container">

	<!-- Header -->

	<header class="header">
			
		<!-- Top Bar -->
		<div class="top_bar">
			<div class="top_bar_container" style="background-color: #cc9a5e">
				<div class="container">
					<div class="row">
						<div class="col">
							<div class="top_bar_content d-flex flex-row align-items-center justify-content-start">
								<ul class="top_bar_contact_list">
									<li><div class="question">Have any questions?</div></li>
									<li>
										<i class="fa fa-phone" aria-hidden="true"></i>
										<div>+91 9322040870</div>
                                        <div> | +91 8369720901</div>
									</li>
									<li>
										<i class="fa fa-envelope-o" aria-hidden="true"></i>
										<div>synergy.aos@gmail.com</div>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>				
		</div>

		<!-- Header Content -->
	
		
		<div class="header_container" style="background-color: #292929">
			<div class="container-fluid">
				<div class="row">
					<div class="col">
						<div class="header_content d-flex flex-row align-items-center justify-content-start">
							<div class="logo_container">
								<a href="#">
									<div class="logo_text" style="color: white">S<span style="color:#d8731a">y</span>nerg<span style="color: #d8731a">y</span></div>
									<br>
									<br>
									<h5 style="color: white">Academy of Science</h5>
								</a>
							</div>
							<nav class="main_nav_contaner ml-auto">
								<ul class="main_nav">
									<li><a href="index.php" style="color: white">Home</a></li>
									<li><a href="about.php" style="color: white">About Us</a></li>
									<li><a href="courses.php" style="color: white">Courses</a></li>
									<li><a href="gallery.php" style="color: white">Image Gallery</a></li>
									<li><a href="contact.php" style="color: white">Contact Us</a></li>
									<li><a href="#notices" style="color: white">Notices</a></li>
									<li><a href="faq.php" style="color: white">FAQ</a></li>
									<li>
								<div class="top_bar_login ml-auto">
									<div class="login_button"><a href="identity.php">Login</a></div>
								</div>
								</li>
								</ul>

								
								<div class="hamburger menu_mm">
									<i class="fa fa-bars menu_mm" aria-hidden="true"></i>
								</div>
							</nav>

						</div>
					</div>
				</div>
			</div>
		</div>
	</header>


	<!-- Menu -->

	<div class="menu d-flex flex-column align-items-end justify-content-start text-right menu_mm trans_400">
		<div class="menu_close_container"><div class="menu_close"><div></div><div></div></div></div>
		<div class="search">
			<form action="#" class="header_search_form menu_mm">
				<input type="search" class="search_input menu_mm" placeholder="Search" required="required">
				<button class="header_search_button d-flex flex-column align-items-center justify-content-center menu_mm">
					<i class="fa fa-search menu_mm" aria-hidden="true"></i>
				</button>
			</form>
		</div>
		<nav class="menu_nav">
			<ul class="menu_mm">
				<li class="menu_mm"><a href="index.html">Home</a></li>
				<li class="menu_mm"><a href="#">About</a></li>
				<li class="menu_mm"><a href="#">Courses</a></li>
				<li class="menu_mm"><a href="#">Blog</a></li>
				<li class="menu_mm"><a href="#">Page</a></li>
				<li class="menu_mm"><a href="contact.html">Contact</a></li>
			</ul>
		</nav>
	</div>
	
	<!-- Home -->

	<div class="home">
		<div class="home_slider_container">
			
			<!-- Home Slider -->
			<div class="owl-carousel owl-theme home_slider">
				
				<!-- Home Slider Item -->
				<div class="owl-item">
					<div class="home_slider_background" style="background-image:url(images/back1.png)"></div>
					<div class="home_slider_content">
						<div class="container">
							<div class="row">
								<div class="col text-center">
									<div class="home_slider_title" style="color: white">The Premium System Education</div>
									<div class="home_slider_subtitle" style="color: white">Future Of Education Technology</div>
									<div class="home_slider_form_container" style="color: white">
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Home Slider Item -->
				<div class="owl-item">
					<div class="home_slider_background" style="background-image:url(images/back2.png)"></div>
					<div class="home_slider_content">
						<div class="container">
							<div class="row">
								<div class="col text-center">
									<div class="home_slider_title">The Premium System Education</div>
									<div class="home_slider_subtitle">Future Of Education Technology</div>
									<div class="home_slider_form_container">
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Home Slider Item -->
				<div class="owl-item">
					<div class="home_slider_background" style="background-image:url(images/home_slider_1.jpg)"></div>
					<div class="home_slider_content">
						<div class="container">
							<div class="row">
								<div class="col text-center">
									<div class="home_slider_title">The Premium System Education</div>
									<div class="home_slider_subtitle">Future Of Education Technology</div>
									<div class="home_slider_form_container">
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>

		<!-- Home Slider Nav -->

		<div class="home_slider_nav home_slider_prev"><i class="fa fa-angle-left" aria-hidden="true"></i></div>
		<div class="home_slider_nav home_slider_next"><i class="fa fa-angle-right" aria-hidden="true"></i></div>
	</div>

	<!-- Features -->

	<div class="features" style="background-color: #c5ad67">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="section_title_container text-center">
						<h2 class="section_title" style="color: white">A WORD OF WELCOME</h2>
						<div class="section_subtitle"><p style="color: white">Welcome to Synergy Academy of Science! We realize that this is the time of excitement and hope for a better future. We assure you that you are at the right place to pursue your dream.

You are entering the entire new academic system that you have encountered before. You will experience the change in study pattern and the need of more efforts to surpass the challenges posed by one of the most competitive examination of the world.

Best and experienced faculty of the field, disciplined and well trained administrative staff, result oriented atmosphere and most efficient system of India you will get in Synergy Academy of Science.

It’s a Challenge, It’s an Experience, It’s an Opportunity

COME, FEEL IT FOR YOURSELVES!

Happy Learning!</p></div>
					</div>
				</div>
			</div>
			<div class="row features_row">
				
				<!-- Features Item -->
				<div class="col-lg-3 feature_col">
					<div class="feature text-center trans_400" style="background-color: #c68d4a">
						<div class="feature_icon"><img src="images/icon_1.png" alt=""></div>
						<h3 class="feature_title" >The Experts</h3>
						<div class="feature_text"><p style="color: black;">Best teaching faculty with teachers having an experience of over 10 years</p></div>
					</div>
				</div>

				<!-- Features Item -->
				<div class="col-lg-3 feature_col">
					<div class="feature text-center trans_400" style="background-color: #c68d4a">
						<div class="feature_icon" ><img src="images/icon_2.png" alt=""></div>
						<h3 class="feature_title" >Books & Library</h3>
						<div class="feature_text"><p style="color: black;" >A well maintained library is available for the students to refer</p></div>
						<br>
					</div>
				</div>

				<!-- Features Item -->
				<div class="col-lg-3 feature_col">
					<div class="feature text-center trans_400" style="background-color: #c68d4a">
						<div class="feature_icon"><img src="images/icon_3.png" alt=""></div>
						<h3 class="feature_title">Best Courses</h3>
						<div class="feature_text"><p style="color: black;">Best courses designed by keeping in mind the current scenarios of the exams</p></div>
					</div>
				</div>

				<!-- Features Item -->
				<div class="col-lg-3 feature_col">
					<div class="feature text-center trans_400" style="background-color: #c68d4a">
						<div class="feature_icon"><img src="images/icon_4.png" alt=""></div>
						<h3 class="feature_title">Award & Reward</h3>
						<div class="feature_text"><p style="color: black;">Ranked among the top 5 coaching institutes of Navi Mumbai</p></div>
						<br>
					</div>
				</div>

			</div>
		</div>
	</div>

	<!-- Popular Courses -->

	<div class="courses">
		<div class="section_background parallax-window" data-parallax="scroll" data-image-src="images/courses_background.jpg" data-speed="0.8"></div>
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="section_title_container text-center">
						<h2 class="section_title" style="color: #d8731a">Courses we offer</h2>
						<div class="section_subtitle"><p style="color: #292929">Following is the list of all the courses that we offer under our banner.</p></div>
					</div>
				</div>
			</div>
			<div class="row courses_row">
				
				<!-- Course -->
				<div class="col-lg-4 course_col">
					<div class="course">
						<div class="course_image"><img src="images/course_1.jpg" alt=""></div>
						<div class="course_body">
							<h3 class="course_title"><a href="course.html" style="color: #d8731a">JEE Main & Advanced</a></h3>
							<div class="course_teacher" style="color: #292929">Mr. John Taylor</div>
							<div class="course_text">
								<p style="color: #292929">This course covers the complete coaching of JEE Main, JEE Advanced and other Engineering entrance exams along with 11th & 12th board (State & CBSE)</p>
							</div>
						</div>
						<div class="course_footer">
							<div class="course_footer_content d-flex flex-row align-items-center justify-content-start">
								<div class="course_info">
									<i class="fa fa-graduation-cap" aria-hidden="true"></i>
									<span style="color: #292929">50 Student</span>
								</div>
								<div class="course_info">
									<i class="fa fa-star" aria-hidden="true"></i>
									<span style="color: #292929">5 Ratings</span>
								</div>
								<div class="course_price ml-auto" style="color: #d8731a">2 years</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Course -->
				<div class="col-lg-4 course_col">
					<div class="course">
						<div class="course_image"><img src="images/course_2.jpg" alt=""></div>
						<div class="course_body">
							<h3 class="course_title"><a href="course.html" style="color: #d8731a">NEET & AIPMT</a></h3>
							<div class="course_teacher" style="color: #292929">Ms. Lucius</div>
							<div class="course_text">
								<p style="color: #292929">This course covers the complete coaching of AIPMT, NEET and other Medical entrance exams along with 11th & 12th board (state & CBSE)</p>
							</div>
						</div>
						<br>
						<div class="course_footer">
							<div class="course_footer_content d-flex flex-row align-items-center justify-content-start">
								<div class="course_info">
									<i class="fa fa-graduation-cap" aria-hidden="true"></i>
									<span style="color: #292929">50 Student</span>
								</div>
								<div class="course_info">
									<i class="fa fa-star" aria-hidden="true"></i>
									<span style="color: #292929">5 Ratings</span>
								</div>
								<div class="course_price ml-auto" style="color: #d8731a">2 years</div>
								
							</div>
						</div>
					</div>
				</div>

				<!-- Course -->
				<div class="col-lg-4 course_col">
					<div class="course">
						<div class="course_image"><img src="images/course_3.jpg" alt=""></div>
						<div class="course_body">
							<h3 class="course_title"><a href="course.html" style="color: #d8731a">11th & 12th + CET</a></h3>
							<div class="course_teacher" style="color: #292929">Mr. Charles</div>
							<div class="course_text">
								<p style="color: #292929">Complete coverage of the 11th & 12th syllabus (state & CBSE)</p>
							</div>
						</div>
						<br>
						<br>
						<div class="course_footer">
							<div class="course_footer_content d-flex flex-row align-items-center justify-content-start">
								<div class="course_info">
									<i class="fa fa-graduation-cap" aria-hidden="true"></i>
									<span style="color: #292929">60 Student</span>
								</div>
								<div class="course_info">
									<i class="fa fa-star" aria-hidden="true"></i>
									<span style="color: #292929">5 Ratings</span>
								</div>
								<div class="course_price ml-auto" style="color: #d8731a"><span></span>2 years</div>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>


	<!-- Events -->

	<div class="events" style="background-color: #cc9a5e">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="section_title_container text-center">
						<h2 class="section_title" style="color: #292929">Our Key Features</h2>
					</div>
				</div>
			</div>
			<div class="row events_row">

				<!-- Event -->
				<div class="col-lg-4 event_col">
					<div class="event event_left">
						<div class="event_image"><img src="images/event_1.jpg" alt=""></div>
						<div class="event_body d-flex flex-row align-items-start justify-content-start">
							<div class="event_content">
								<div class="event_title"><a href="#" style="color: #292929">We rank among the top 5 coaching institutes of Navi Mumbai</a></div>
							</div>
						</div>
					</div>
				</div>

				<!-- Event -->
				<div class="col-lg-4 event_col">
					<div class="event event_mid">
						<div class="event_image"><img src="images/event_2.jpg" alt=""></div>
						<div class="event_body d-flex flex-row align-items-start justify-content-start">
							<div class="event_date">
							</div>
							<div class="event_content">
								<div class="event_title"><a href="#" style="color: #292929">World class amenities</a></div>
							</div>
						</div>
					</div>
				</div>

				<!-- Event -->
				<div class="col-lg-4 event_col">
					<div class="event event_right">
						<div class="event_image"><img src="images/event_3.jpg" alt=""></div>
						<div class="event_body d-flex flex-row align-items-start justify-content-start">
							<div class="event_date">
							</div>
							<div class="event_content">
								<div class="event_title"><a href="#" style="color: #292929">Indivisual Monitering</a></div>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>

	<!-- Team -->

	<div class="team">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="section_title_container text-center">
						<h2 class="section_title">The Best Tutors in Town</h2>
						<div class="section_subtitle"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vel gravida arcu. Vestibulum feugiat, sapien ultrices fermentum congue, quam velit venenatis sem</p></div>
					</div>
				</div>
			</div>
			<div class="row team_row">
				
				<!-- Team Item -->
				<div class="col-lg-3 col-md-6 team_col">
					<div class="team_item">
						<div class="team_image"><img src="images/teacher2_edit1.jpg" alt=""></div>
						<div class="team_body">
							<div class="team_title"><a href="#">Rahul Arora</a></div>
							<div class="team_subtitle">Physics</div>
							<div class="social_list">
								<ul>
									<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>

				<!-- Team Item -->
				<div class="col-lg-3 col-md-6 team_col">
					<div class="team_item">
                        <div class="team_image"><img src="images/team_1.jpg" alt=""></div>
						<div class="team_body">
							<div class="team_title"><a href="#">Abhishek Arora</a></div>
							<div class="team_subtitle">Mathematics</div>
							<div class="social_list">
								<ul>
									<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>

				<!-- Team Item -->
				<div class="col-lg-3 col-md-6 team_col">
					<div class="team_item">
						<div class="team_image"><img src="images/team_3.jpg" alt=""></div>
						<div class="team_body">
							<div class="team_title"><a href="#">John Tyler</a></div>
							<div class="team_subtitle">Quantum mechanics</div>
							<div class="social_list">
								<ul>
									<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>

				<!-- Team Item -->
				<div class="col-lg-3 col-md-6 team_col">
					<div class="team_item">
						<div class="team_image"><img src="images/teacher1_edit1.jpg" alt=""></div>
						<div class="team_body">
							<div class="team_title"><a href="#">Dr. Aditi A. Phapale</a></div>
							<div class="team_subtitle">Biology</div>
							<div class="social_list">
								<ul>
									<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
            </div>
		</div>
	</div>


	<!-- Latest News -->

	<div class="news" id="notices" style="background-color: #292929">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="section_title_container text-center">
						<h2 class="section_title" style="color: #d8731a">Latest updates</h2>
						<div class="section_subtitle"><p style="color: white">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vel gravida arcu. Vestibulum feugiat, sapien ultrices fermentum congue, quam velit venenatis sem</p></div>
					</div>
				</div>
			</div>
			
			<div class="row news_row">

				<div class="col-lg-5 news_col">
					<div class="news_posts_small">
                    <?php include "includes/notice_display.php"; ?>

					</div>
				</div>
			</div>
		</div>
	</div>
	
	
	<!-- Counter -->
	
	<div class="counter">
		<div class="counter_background" style="background-image:url(images/cback.png)"></div>
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="counter_content">
						<h2 class="counter_title">Enroll Now</h2>
						<div class="counter_text"><p>Be ahead of others. Join the league. Get trained under the guidance of some of the best faculties of Navi Mumbai. Experience teaching as never before.</p></div>

						<!-- Milestones -->

						<div class="milestones d-flex flex-md-row flex-column align-items-center justify-content-between">
							
							<!-- Milestone -->
							<div class="milestone">
								<div class="milestone_counter" data-end-value="2" style="color: white">0</div>
								<div class="milestone_text">years</div>
							</div>

							<!-- Milestone -->
							<div class="milestone">
								<div class="milestone_counter" data-end-value="250" data-sign-after="" style="color: white">0</div>
								<div class="milestone_text">Students</div>
							</div>

							<!-- Milestone -->
							<div class="milestone">
								<div class="milestone_counter" data-end-value="35" data-sign-after="" style="color: white">0</div>
								<div class="milestone_text">Top rankers</div>
							</div>

							<!-- Milestone -->
							<div class="milestone">
								<div class="milestone_counter" data-end-value="200" style="color: white">0</div>
								<div class="milestone_text">Qualifies</div>
							</div>

						</div>
					</div>

				</div>
			</div>

			<div class="counter_form">
				<div class="row fill_height">
					<div class="col fill_height">
						<form class="counter_form_content d-flex flex-column align-items-center justify-content-center" action="" method="post">
							<div class="counter_form_title" style="color: #d8731a">Interested?</div>
							<p style="color: #292929">Please fill the below given form</p>
							<input type="text" class="counter_input" name="name" placeholder="Your Name:" required="required">
							<input type="email" class="counter_input" name="email" placeholder="email id" required="required">
							<select name="counter_select" id="counter_select" class="counter_input counter_options">
								<option>Choose Course</option>
								<option>JEE mains & Advanced</option>
								<option>NEET & AIPMT</option>
								<option>11th & 12th + CET</option>
								<option>plain 11th & 12th</option>
							</select>
							<textarea class="counter_input counter_text_input" name="msg" placeholder="Message:" required="required"></textarea>
							<button type="submit" name = "submit" class="counter_form_button" style="background-color: #d8731a">submit now</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>


	<!-- Footer -->

	<footer class="footer" style="background-color: #141313">
		<div class="footer_background" style="background-image:url(images/footer_background.png)"></div>
		<div class="container">
			<div class="row footer_row">
				<div class="col">
					<div class="footer_content">
						<div class="row">

							<div class="col-lg-3 footer_col">
					
								<!-- Footer About -->
								<div class="footer_section footer_about">
									<div class="footer_logo_container">
										<a href="#">
											<div class="footer_logo_text">S<span style="color: #d8731a">y</span>nerg<span style="color: #d8731a">y</span></div>
											<br>
											<h4 style="color: white">Academy of Science</h4>
										</a>
									</div>
									<div class="footer_about_text">
										<p>IIT-JEE | Medical | CBSE Board | Olympiad</p>
									</div>
									<div class="footer_social">
										<ul>
											<li><a href="https://www.facebook.com/synergyacademyofscience/"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
											<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
											<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
										</ul>
									</div>
								</div>
								
							</div>

							<div class="col-lg-3 footer_col">
					
								<!-- Footer Contact -->
								<div class="footer_section footer_contact">
									<div class="footer_title" style="color: #d8731a">Contact Us</div>
									<div class="footer_contact_info">
										<ul>
											<li>Email: synergy.aos@gmail.com</li>
											<li>Phone:  +91 9322040870 | +91 8369720901</li>
											<li>Shop No. 16, Chaturbhuj Society, Shilp Chowk, Sector 21, Kharghar, Navi Mumbai - 410210, Next to IDBI Bank</li>
										</ul>
									</div>
								</div>
								
							</div>

							<div class="col-lg-3 footer_col">
					
								
							</div>

							<div class="col-lg-3 footer_col clearfix">
					
								
							</div>

						</div>
					</div>
				</div>
			</div>

			<div class="row copyright_row">
				<div class="col">
					<div class="copyright d-flex flex-lg-row flex-column align-items-center justify-content-start">
						
					</div>
				</div>
			</div>
		</div>
	</footer>
</div>
<script type="text/javascript">
    $('.awNotices').append('<span class="controller fa fa-pause"></span>');
$('.awNotices a:nth-of-type(1)').addClass('active');

function awNotice() {
  if(!$('.awNotices').hasClass('stopped')){
  var $active = $('.awNotices a.active');
  var $next = $active.next('a');    
  
  if ($next.length){
  $next.addClass('active');
  $active.removeClass('active');
  }else{
    $active.removeClass('active');
		$('.awNotices a:first-of-type').addClass('active');
  }
  }
}

$('.awNotices .controller').click(function(){
  $(this).toggleClass('fa-pause fa-play');
  $('.awNotices').toggleClass('stopped');
})

function awNotices(timer){
    setInterval( "awNotice()", timer);
}

awNotices(4500);

</script>
<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="js/custom.js"></script>
</body>
</html>