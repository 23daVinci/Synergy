<?php 

if(isset($_POST['submit'])){
	$slot1_V = $_POST['V-1'];
	$slot1_VI = $_POST['VI-1'];
	$slot1_VII = $_POST['VII-1'];
	$slot1_VIII = $_POST['VIII-1'];
	
	$slot2_V = $_POST['V-2'];
	$slot2_VI = $_POST['VI-2'];
	$slot2_VII = $_POST['VII-2'];
	$slot2_VIII = $_POST['VIII-2'];
	
	$slot3_V = $_POST['V-3'];
	$slot3_VI = $_POST['VI-3'];
	$slot3_VII = $_POST['VII-3'];
	$slot3_VIII = $_POST['VIII-3'];
	
	$slot4_V = $_POST['V-4'];
	$slot4_VI = $_POST['VI-4'];
	$slot4_VII = $_POST['VII-4'];
	$slot4_VIII = $_POST['VIII-4'];
	
	$slot5_V = $_POST['V-5'];
	$slot5_VI = $_POST['VI-5'];
	$slot5_VII = $_POST['VII-5'];
	$slot5_VIII = $_POST['VIII-5'];

	
	$query = "INSERT INTO `student` (`slot`,`V`, `VI`, `VII`, `VIII`) VALUES ('slot-1','$slot1_V', '$slot1_VI', '$slot1_VII', '$slot1_VIII'),
	('slot-2','$slot2_V', '$slot2_VI', '$slot2_VII', '$slot2_VIII'),('slot-3','$slot3_V', '$slot3_VI', '$slot3_VII', '$slot3_VIII'),
	('slot-4','$slot4_V', '$slot4_VI', '$slot4_VII', '$slot4_VIII'),('slot-5','$slot5_V', '$slot5_VI', '$slot5_VII', '$slot5_VIII');";
	
	$create_table_query = mysqli_query($conn,$query);
	
	if(!$create_table_query){
		die(mysqli_error($conn));
	}
	else{
		echo "submitted";
	}
	
	
		
		
		
}

elseif(isset($_POST['reset'])){
	$query = " DELETE FROM `student`";
	$delete_query = mysqli_query($conn,$query);
	
	if(!$delete_query){
		die(mysqli_error($conn));
		
	}
	else{
		header("Location:profile.php ");
	
	}
	
	
}

/* NOtice and Calendar section */

elseif(isset($_POST['reset_notice'])) {
	$notice_del_query = " DELETE FROM `notices`";
	$notice_del_result = mysqli_query($conn,$notice_del_query);
	
	if(!$notice_del_result){
		die(mysqli_error($conn));
		
	}
	else{
		header("Location:profile.php ");
        echo "Database successfully updated";
	
	}
}


?>