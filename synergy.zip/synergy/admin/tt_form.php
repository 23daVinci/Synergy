<br>
<br>
 <form action="includes/tt_entry.php" method="post"> 
<table class="table" border="3" cellpadding="5" align ="center" width="100%">
<tr> 
	<th colspan="9">
		<h1>Time Table </h1>
		
	</th>
</tr>
<tr>
<th>Time</th>
<th>Mon</th>
<th>Tue</th>
<th>Wed</th>
<th>Thur</th>
<th>Fri</th>
<th>Sat</th>

</tr>

<tr>
<th>Slot 1</th>

<td>

	<select name="monday1" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="tuesday1" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="wednesday1" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="thursday1" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="friday1" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="saturday1" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>

</tr>
<tr>
<th>Slot 2</th>

<td>

	<select name="monday2" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="tuesday2" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="wednesday2" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="thursday2" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="friday2" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="saturday2" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>

</tr>

<tr>
<th>Slot 3</th>

<td>

	<select name="monday3" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="tuesday3" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="wednesday3" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="thursday3" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="friday3" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="saturday3" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
</tr>

<tr>
<th>Slot 4</th>

<td>

	<select name="monday4" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="tuesday4" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="wednesday4" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="thursday4" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="friday4" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="saturday4" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
</tr>

<tr>
<th>Slot 5</th>

<td>

	<select name="monday5" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="tuesday5" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="wednesday5" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="thursday5" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="friday5" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="saturday5" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>

</tr>
	
</table>
<br/>
<br/>
	 <button type="submit" class="btn btn-success" name="submit">Submit</button>
	 <button type="submit" class="btn btn-danger" name="reset">Reset</button>
 </form>
 