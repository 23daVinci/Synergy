<br>
<br>
 <form action="tt_entry.php" method="post"> 
<table class="table" border="3" cellpadding="5" align ="center" width="100%">
<tr> 
	<th colspan="9">
		<h1>Time Table </h1>
		
	</th>
</tr>
<tr>
<th>Time</th>
<th>Mon</th>
<th>Tue</th>
<th>Wed</th>
<th>Thur</th>

</tr>

<tr>
<th>Slot 1</th>

<td>

	<select name="V-1" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="VI-1" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="VII-1" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="VIII-1" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="sans">Sanskrit</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>
	
</td>

</tr>
<tr>
<th>Slot 2</th>

<td>

	<select name="V-2" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="VI-2" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="VII-2" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="VIII-2" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="sans">Sanskrit</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>
	
</td>

</tr>

<tr>
<th>Slot 3</th>

<td>

	<select name="V-3" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="VI-3" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="VII-3" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="VIII-3" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="sans">Sanskrit</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>
	
</td>

</tr>

<tr>
<th>Slot 4</th>

<td>

	<select name="V-4" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="VI-4" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="VII-4" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="VIII-4" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="sans">Sanskrit</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>
	
</td>

</tr>

<tr>
<th>Slot 5</th>

<td>

	<select name="V-5" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="VI-5" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="VII-5" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>

</td>
<td>

	<select name="VIII-5" style = "width : 100%">
		<option selected="selected"></option>
		<option value="off">OFFDAY!!</option>
		<option value="maths">Mathematics</option>
		<option value="sci">Science</option>
		<option value="hist_civ">History/Civics</option>
		<option value="geog">Geography</option>
		<option value="hindi">Hindi</option>
		<option value="sans">Sanskrit</option>
		<option value="eng">English</option>
		<option value="mar">Marathi</option>
	</select>
	
</td>

</tr>
	
</table>
<br/>
<br/>
	 <button type="submit" class="btn btn-success" name="submit">Submit</button>
	 <button type="submit" class="btn btn-danger" name="reset">Reset</button>
 </form>
 