<?php 

$db['db_host']="localhost";
	$db['db_user']="root";
	$db['db_pass']="";
	$db['db_name']="school";

	foreach($db as $key => $value){
		define(strtoupper($key),$value);

	}
	$conn = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);

 if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
?>