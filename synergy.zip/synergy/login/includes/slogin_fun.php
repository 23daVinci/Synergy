
<?php session_start();  

$db['db_host']="localhost";
$db['db_user']="root";
$db['db_pass']="";
$db['db_name']="synergy";
 
foreach($db as $key => $value){
	define(strtoupper($key),$value);
	
}


$conn = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);



include("function.php");

if(isset($_POST['login'])){

$username = $_POST['username'];
$password = $_POST['password'];
    
$username = mysqli_real_escape_string($conn, $username);
$password = mysqli_real_escape_string($conn, $password);
    

$username = string_check($username);
$password = string_check($password);



$query = "SELECT * FROM students where username= '$username'";
	
$select_students_query = mysqli_query($conn,$query);


if(!$select_students_query ){
	die("Error ocurred ".mysqli_error($conn));
}

        while($row = mysqli_fetch_array($select_students_query)){
        $user_name=$row['username'];
            //$username = $row['name'];
        $user_password = $row['user_password'];
            $user_firstname = $row['fname'];
            $user_lastname = $row['lname'];
            $user_doa = $row['doa'];
            $user_address = $row['address'];
            $user_phone = $row['phone'];
            $user_image= $row['image'];
            $user_class = $row['class'];
            $user_course = $row['course'];
    }
    
  
    $password = crypt($password,$user_password);
	$password = substr($password,0,50);
	/*echo $password."<br>";*/
	
	
	if($password !== $user_password && $roll_no !== $user_roll_no){
        header("Location:slogin.php");
        echo "Invalid username or password";
    }
    

	
	else	if($password == $user_password && $id == $user_id){
            
            $_SESSION['roll_no'] = $roll_no;
			$_SESSION['fname'] = $user_firstname;
            $_SESSION['lname'] = $user_lastname;
            $_SESSION['doa'] = $user_doa;
            $_SESSION['gender'] = $user_gender;
            $_SESSION['address'] = $user_address;
            $_SESSION['phone'] = $user_phone;
            $_SESSION['image'] = $user_image;
            $_SESSION['class'] = $user_class;
            $_SESSION['course'] = $user_course;
            
            
            
           
            
            
			/*echo"<br> password";*/
			header("Location:../students/profile.php");
		}
    
		else{
			echo"<br>invalid username or password";
        }
    
}

	
	

?>

