<?php 


$conn = mysqli_connect("localhost","root","","synergy");

if(mysqli_connect_error()){
	die(mysqli_error($conn));
}
if(isset($_POST['quest_gen'])){
	
	$quest = $_POST['quest'];
	$opt1 = $_POST['opt1'];
	$opt2 = $_POST['opt2'];
	$opt3 = $_POST['opt3'];
	echo $correct_ans = $_POST['cor_ans'];
	if(empty($correct_ans)){
		$correct_ans = "default";
	}elseif($correct_ans === "1"){
		$correct_ans = $opt1;
	}
	elseif($correct_ans === "2"){
		$correct_ans = $opt2;
	}elseif($correct_ans === "3"){
		$correct_ans = $opt3;
	}else{
		
	}

$query = "INSERT INTO `quest` (`quest`, `correct_ans`, `opt_1`, `opt_2`, `opt_3`) VALUES ('$quest', '$correct_ans', '$opt1', '$opt2', '$opt3')";
$result = mysqli_query($conn,$query);
if(!$result){
	die(mysqli_error($conn));
}
else{
	echo "submmited";
}
}


?>







<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>QUESTION GENRATOR</title>
</head>
<body>
<h1 align="center">Enter the quest</h1>
	<form action="" method="post">
	
		<p>QUESTION</p>
		<input type="text" name="quest" id="quest"><br><br>
		<p>opt1</p>
		<input type="radio" name="cor_ans" id="cor_ans" value="1"><input type="text" name="opt1" id="opt1"><br><br>
		<p>opt2</p>
		<input type="radio" name="cor_ans" id="cor_ans" value="2"><input type="text" name="opt2" id="opt2"><br><br>
		<p>opt3</p>
		<input type="radio" name="cor_ans" id="cor_ans" value="3"><input type="text" name="opt3" id="opt3"><br><br>
		<!--<input type="text" name="opt4" id="opt4"><br><br>-->
		
		<button type="submit" name="quest_gen">Submit</button>
		
	</form>

	
</body>
</html>