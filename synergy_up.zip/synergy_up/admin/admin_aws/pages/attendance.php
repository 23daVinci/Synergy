<?php include "../../includes/attendance.php"; ?>
<!DOCTYPE html>
<html>
    <head>
        <title>Synergy</title>
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </head>
           <body>
           <div class="container">    
            <!-- Attendance -->
            <div class="tab_panel tab_panel_3">
                <h2>Enter attendence details.</h2>
                <br>
                <br>
                <form action="" method="post">

                       <p>Select date:</p>
                    <input type="date" name="adate">
                    <br>
                    <br>
                    <p>Roll no.:</p>
                    <input type="text" name="aroll">
                    <br>
                    <br>
                    <h6>check the box if the student is present</h6>
                    <br>
                    <table class="table">
                        <thead>
                        <th>subject</th>
                        <th>present</th>
                        </thead>
                        <tbody>
                           <tr>
                            <td>maths</td>
                              <td>
                               <select name="asub1" id="asub1">
                                   <option value="present">present</option>
                                   <option value="absent">absent</option>
                               </select>
                               </td>
                            </tr>
                            <tr>
                            <td>physics</td>
                               <td>
                                <select name="asub2" id="asub2">
                                   <option value="present">present</option>
                                   <option value="absent">absent</option>
                               </select>
                                </td>
                            </tr>
                            <tr>
                            <td>chemistry</td>
                               <td>
                                <select name="asub3" id="asub3">
                                   <option value="present">present</option>
                                   <option value="absent">absent</option>
                               </select>
                                </td>
                            </tr>
                            <tr>
                            <td>biology</td>
                               <td>
                                <select name="asub4" id="asub4">
                                   <option value="present">present</option>
                                   <option value="absent">absent</option>
                               </select>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <br>
                    <input type="submit" class="btn btn-success" name="asubmit" value="submit">
                </form>
            </div>
               </div>
    </body>
</html>