<?php include "../../includes/marks_enter.php"; ?>
     <!DOCTYPE html>
      <html>
      <head>
          <title>Synergy</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<style>
    body{
        background-image: url(../images/marks.png);
    }
    
       div.row {
  background-color: rgba(255, 255, 255, 0.8);
  border-radius: 30px;
  padding: 10px;
  margin: 10px;
    }
          </style>
            </head>
  
<body>
    <br>
    <br>
    <br>
    <br>
<div class="container">
        <div class="row">
            <div class="col-md-9 col-sm-12"> 
       <!-- Performance -->
       <br>
       <br>
       <br>
        <div class="tab_panel tab_panel_2">
            <div class="tab_panel_content">
            <h2>Please fill the colummns given below to update the test marks.</h2>
            <br>
<form action="" method="post">
    <div class="form-group">
            <label for="roll">Roll No.: </label>
        <input type="text" name="roll" />
    </div>



    <div class="form-group">
        <label>Subject1 : </label>
        <input type="text" name="sub1"/>
        </div>

    <div class="form-group">
        <label>Subject2 : </label>
        <input type="text" name="sub2" />
    </div>

    <div class="form-group">
        <label>Subject3 : </label>
        <input type="text" name="sub3"/>
    </div>

    <div class="form-group"><label>Subject4 : </label>
        <input type="text" name="sub4"/>
    </div>
                <br>
                <label>Test date: </label>
                <input type="date" name="test_date" value="test_date">
                <br>
                <br>
                 <select name="batch" class="form-group" id="batch">
                <option value="batch1">Batch 1</option>
                <option value="batch2">Batch 2</option>
                <option value="batch3">Batch 3</option>
                <option value="batch4">Batch 4</option>
            </select>

             <select name="test_name" class="form-group" id="test">
                <option value="test1">test 1</option>
                <option value="test2">test 2</option>
                <option value="test3">test 3</option>
                <option value="test4">test 4</option>
            </select>

                                <br>
<br>
<p class="">
        <input type="submit" class="btn btn-success" name="add"  value="Add" />
</p>
</form>

            </div>

        </div>
    </div>
    </div>
    </div>
          </body>
</html>
