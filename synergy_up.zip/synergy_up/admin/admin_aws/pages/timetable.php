<?php include "../../includes/tt_entry.php"; ?>
<!DOCTYPE HTML>
<html>
    <head>
        <title>Synergy</title>
          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<style>
    body{
        background-image: url(../images/tt.png);
    }   
    
     div.row {
  background-color: rgba(255, 255, 255, 0.8);
  border-radius: 30px;
  padding: 10px;
  margin: 10px;
    }
</style>
    </head>
               
    <body>
       <br>
       <br>
        <div class="container">
        <div class="row">
            <div class="col-md-9 col-sm-12">             
             <!-- Timetable -->
            <div class="tab_panel active">
                <h1>Update Timetable</h1>
                <div class="tab_panel_content">
            <div class="tab_panel_section">
                        <h4>Fill in the form and then click submit to update the timetable.</h4>
                        <div class="tab_panel_text">
                        <?php include "../../tt_form.php"; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
            </div>
        </div>
        </body>
</html>