<?php
if(isset($_POST['submit'])) { 
    
    $rank = $_POST['rank'];
    $name = $_POST['name'];
    $percentage = $_POST['percentage'];
    
        

    $mysql_hostname  =  "localhost";
    $mysql_user  =  "root"; 
    $mysql_password  =  "";
    $mysql_database  =  "synergy";

    $conn  =  mysqli_connect($mysql_hostname,$mysql_user,$mysql_password,$mysql_database); 
    
    $query = "INSERT INTO toppers(rank,name,score) VALUES('$rank','$name','$percentage')";
    
    $result = mysqli_query($conn, $query);
    
    if(!$result) {
        
        die("Could not update success stories section");
    }
    else {
        
        echo "Successfully updated success stories section!!";
    }
    
    
    
}

?>