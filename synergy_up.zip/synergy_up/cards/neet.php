<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <!-- This file has been downloaded from Bootsnipp.com. Enjoy! -->
    <title>Synergy</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="http://netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">
        @import url('https://fonts.googleapis.com/css?family=Josefin+Sans:100,300,400,600,700');

body{
    background-image: url(images/neet_back.png);
    font-family: 'Josefin Sans', sans-serif;
}
        
         div#ab {
  background-color: rgba(255, 255, 255, 0.8);
  border-radius: 30px;
  padding: 10px;
  margin: 10px;
    }

h3{
     font-family: 'Josefin Sans', sans-serif;
}

.box{
    padding:60px 0px;
}

.box-part{
    background:#FFF;
    border-radius:10px;
    padding:60px 10px;
    margin:30px 0px;
}

.box-part:hover{
    background:#4183D7;
}

.box-part:hover .fa , 
.box-part:hover .title , 
.box-part:hover .text ,
.box-part:hover a{
    color:#FFF;
    -webkit-transition: all 1s ease-out;
    -moz-transition: all 1s ease-out;
    -o-transition: all 1s ease-out;
    transition: all 1s ease-out;
}

.text{
    margin:20px 0px;
}

.fa{
     color:#4183D7;
}
    </style>
    <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
</head>
<body>
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"> 

<!--
    instagram: www.instagram.com/programmingtutorial
    site: programlamadersleri.net
-->
        <div class="box">

    <div class="container">
       
        <div class="row" id="ab">
            <div class="col-md-9 col-sm-12"> 
        <h1 style="text-align: center; color: #4E2E28; font-family:Serif" class="display-3"><b>Practice questions of 11th std</b></h1>
            </div>
        </div>
     	<div class="row">
			 
			    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
               
					<div class="box-part text-center">
                        
						<div class="title">
							<h3>Physics</h3>
						</div>
                        
						<div class="text">
							<span>Solve physics questions</span>
						</div>
                        
						<a href="chapters/physics/physics11.php">give test</a>
                        
					 </div>
				</div>	 
				
				 <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
               
					<div class="box-part text-center">
                    
						<div class="title">
							<h3>Chemistry</h3>
						</div>
                        
						<div class="text">
							<span>Solve Chemistry questions</span>
						</div>
                        
						<a href="chapters/chemistry/chem11.php">give test</a>
                        
					 </div>
				</div>	 
				
				 <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
               
					<div class="box-part text-center">
                        
						<div class="title">
							<h3>Biology</h3>
						</div>
                        
						<div class="text">
							<span>Solve Biology questions</span>
						</div>
                        
						<a href="chapters/maths/maths11.php">give test</a>
                        
					 </div>
				</div>	 
				 
		
		</div>
           <br>
           <div class="row" id="ab">
            <div class="col-md-9 col-sm-12"> 
                <h1 style="text-align: center; color: #4E2E28; font-family:Serif" class="display-3"><b>Practice questions of 12th std</b></h1>
               </div>
        </div>
        	<div class="row">
			 
			    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
               
					<div class="box-part text-center">
                        
						<div class="title">
							<h3>Physics</h3>
						</div>
                        
						<div class="text">
							<span>Solve physics questions</span>
						</div>
                        
						<a href="../online_test/physics.php">give test</a>
                        
					 </div>
				</div>	 
				
				 <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
               
					<div class="box-part text-center">
                    
						<div class="title">
							<h3>Chemistry</h3>
						</div>
                        
						<div class="text">
							<span>Solve Chemistry questions</span>
						</div>
                        
						<a href="../online_test/chemistery.php">give test</a>
                        
					 </div>
				</div>	 
				
				 <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
               
					<div class="box-part text-center">
                        
						<div class="title">
							<h3>Biology</h3>
						</div>
                        
						<div class="text">
							<span>Solve Biology questions</span>
						</div>
                        
						<a href="../online_test/maths.php">give test</a>
                        
					 </div>
				</div>	 
				 
		
		</div>		
    </div>
</div>
<script type="text/javascript">

</script>
</body>
</html>
