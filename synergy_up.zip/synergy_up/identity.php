<!DOCTYPE html>
<html lang="en">
<head>
    
    <!-- title of the site -->
  <title>Synergy</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
<style>
.demo{ background-image: url("images/iden.png"); }
.pricingTable{
    text-align: center;
    background: #28b6f6;
    border-radius: 102px 0 102px 0;
    overflow: hidden;
    transition: all 0.3s ease 0s;
}
.pricingTable:hover{ box-shadow: 0 0 10px rgba(0,0,0,0.5); }
.pricingTable .pricingTable-header{
    margin: -2px -5px 0;
    position: relative;
}
.pricingTable .pricing-content{
    padding: 0;
    margin: -25px 0 0 0;
    list-style: none;
}
.pricingTable .pricing-content li{
    font-size: 20px;
    color: #fff;
    line-height: 50px;
    letter-spacing: 1px;
    border-bottom: 1px solid #fff;
}
.pricingTable .pricing-content li.disable{ color: rgba(255,255,255,0.5); }
.pricingTable .pricing-content li:last-child{ border-bottom: none; }
.pricingTable .pricingTable-signup{
    padding: 25px 0;
}
.pricingTable .pricingTable-signup a path,
.pricingTable .pricingTable-signup a text{ transition: all 0.3s ease 0s; }
.pricingTable .pricingTable-signup a:hover path{
    fill: #34454d;
    stroke: #fff;
    stroke-dasharray: 5,3;
}
.pricingTable .pricingTable-signup a:hover text{ fill: #fff; }
@media only screen and (max-width: 990px){
    .pricingTable{ margin-bottom: 30px; }
}    
    </style>
</head>
<body>


<div class="demo">
   <br>
   <br>
    <h1 style="color:#ff0000"><b>Please select one of the following</b></h1>
   <br>
   <br>
   <br>
    <div class="container">
        <div class="row">
           <div class="col-sm-4">
               <p>  </p>
           </div>
            <div class="col-sm-4">
                <div class="pricingTable">
                    <div class="pricingTable-header">
                        <svg x="0px" y="0px" viewBox="0 0 260 180">
                            <path fill="#34454d" stroke-dasharray="5,5" stroke="#fff" d="M0,180.928c0,0,0-108.489,0-143.333C1.637,23.582,8.907,0,42.088,0C75.271,0,260,0,260,0v72.841
                            c0,0-2.667,37.424-43.877,45.563C177.693,125.992,6.26,130.42,0,180.928z"></path>
                            <text transform="matrix(1.0078 0 0 1 75.9497 40.8887)" fill="#fff" font-size="23.726">STUDENT</text>
                            <text transform="matrix(1.0078 0 0 1 90.9497 65.8887)" fill="#fff" font-size="23.726">LOGIN</text>
                        </svg>
                    </div>
                    <div class="pricingTable-signup">
                        <svg x="0" y="0" viewBox="-35 0 160 30">
                            <a href="login/slogin.php">
                                <path fill="#fff" d="M13.12,5.867c17.786-0.834,68.654-5.473,68.654-5.473s8.203-1.945,7.445,5.473
                                c-0.757,7.417-4.037,16.782-4.037,16.782s-1.667,5.881-9.719,6.932c-8.961,0.852-50.858-0.983-67.771,0
                                c-2.718,0.158-9.935,0.256-7.446-7.66c2.736-9.18,3.408-10.459,3.408-10.459S5.647,5.86,13.12,5.867z"></path>
                                <text transform="matrix(1 0 0 1 15.5055 21.0098)" fill="#34454D" font-size="10" font-weight="600">I'm a student</text>
                            </a>
                        </svg>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="pricingTable">
                    <div class="pricingTable-header">
                        <svg x="0px" y="0px" viewBox="0 0 260 180">
                            <path fill="#34454d" stroke-dasharray="5,5" stroke="#fff" d="M0,180.928c0,0,0-108.489,0-143.333C1.637,23.582,8.907,0,42.088,0C75.271,0,260,0,260,0v72.841
                            c0,0-2.667,37.424-43.877,45.563C177.693,125.992,6.26,130.42,0,180.928z"></path>
                            <text transform="matrix(1.0078 0 0 1 75.9497 40.8887)" fill="#fff" font-size="23.726">ADMIN</text>
                            <text transform="matrix(1.0078 0 0 1 90.9497 65.8887)" fill="#fff" font-size="23.726">LOGIN</text>
                        </svg>
                    </div>
                    <div class="pricingTable-signup">
                        <svg x="0" y="0" viewBox="-35 0 160 30">
                            <a href="login/alogin.php">
                                <path fill="#fff" d="M13.12,5.867c17.786-0.834,68.654-5.473,68.654-5.473s8.203-1.945,7.445,5.473
                                c-0.757,7.417-4.037,16.782-4.037,16.782s-1.667,5.881-9.719,6.932c-8.961,0.852-50.858-0.983-67.771,0
                                c-2.718,0.158-9.935,0.256-7.446-7.66c2.736-9.18,3.408-10.459,3.408-10.459S5.647,5.86,13.12,5.867z"></path>
                                <text transform="matrix(1 0 0 1 15.5055 21.0098)" fill="#34454D" font-size="10" font-weight="600">I'm an admin</text>
                            </a>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
    </div>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
</div>


</body>
</html>