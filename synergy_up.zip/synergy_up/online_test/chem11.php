<?php
session_start();
$conn = mysqli_connect("localhost","root","","synergy");

if(mysqli_connect_error()){
	die(mysqli_error($conn));
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<title>quiz</title>

<style>
    body {
    background-image: url("images/back.png");
    background-color: white;
    }
    .center {
    display: block;
    margin-left: auto;
    margin-right: auto;
    width: 50%;
}
    </style>
</head>

<body>
<!-- heading -->
<h1 style="text-align:center; font-family: Georgia">Synergy Academy of Science</h1>
    <h2 style="text-align:center">Online MCQ</h2>
<div class="row container">
   <div class="col-lg-4">
       <p>  </p>
   </div>
   <div class="col-lg-4">
       <p> </p>
   </div>
   <div col-lg-4>
      <h4 class="text-right">Time remaining:</h4>
       <h4 class="text-right" id="demo"></h4>
   </div>
</div>
   <br>

        <div class="container jumbotron">
    <h3 style="text-align:center; color:red"><u>Physics</u></h3>
    <br>
   
<form action="test/chem11_ans.php" method="post">

<?php 

    if(isset($_POST['submit'])){
    $chap = $_POST['chap'];    
        
	$query = "select * from `chem11` WHERE chap= '$chap'";
	$result = mysqli_query($conn,$query);
	/* $count = mysqli_num_rows($result); */
	if(!$result){
		die(mysqli_error($conn));
		
	}
	$array=array("");
	$img=array("");
	$quest_array = array("");
	$cor_ans_array = array("");
    $count = mysqli_num_rows($result);
	while($row = mysqli_fetch_array($result)){
		
		$quest_id = $row['quest_id'];
		$quest = $row['quest'];
	    $opt_1 = $row['opt_1'];
		$opt_2 = $row['opt_2'];
		$opt_3 = $row['opt_3'];
		$opt_4 = $row['opt_4'];
        $image = $row['image'];
        
        if(empty($image)){
            $image = "";
        }else{
             $image = '<img src="test/images/'.$image.'" alt="something went wrong" class="center" width="200px" height="300px">';
            
            
        }
        
       
		$correct_ans = $row['correct_ans'];
		
		$opt_1 = sprintf('<input type="radio" name="%s" id="%s" value="%s">%s<br>',$quest_id,$quest_id,$opt_1,$opt_1);
		$opt_2 = sprintf('<input type="radio" name="%s" id="%s" value="%s">%s<br>',$quest_id,$quest_id,$opt_2,$opt_2);
		$opt_3 = sprintf('<input type="radio" name="%s" id="%s" value="%s">%s<br>',$quest_id,$quest_id,$opt_3,$opt_3);
		$opt_4 = sprintf('<input type="radio" name="%s" id="%s" value="%s">%s<br>',$quest_id,$quest_id,$opt_4,$opt_4);
		
		$range = array($quest .'<br><br>' .$image."<br>". $opt_1."\t".$opt_2."\t".$opt_3."\t".$opt_4."\n");
		$array = array_merge($range,$array);
		
		$quest_id = array($quest_id);
		$quest_array = array_merge($quest_id,$quest_array);
		
		$correct_ans = array($correct_ans);
		$cor_ans_array = array_merge($correct_ans,$cor_ans_array);
		
	}
	

	$re =array_pop($array);
	$re =array_pop($quest_array);
	$_SESSION['quest'] = $quest_array;
	$_SESSION['corr_ans'] = $cor_ans_array;


	 $rand_keys = shuffle($array);
	


	for($i = 0; $i<$count;$i++){
		
		$j = $i + 1; 
	 		echo $j." .&nbsp;&nbsp;". $array[$i] . "<br>"; 
		
		
} 
	
    }
	

	
	
	?>
	<input type="submit" value="SUBMIT" id="myBtn" name="ans">
	
</form>
    </div>


	
</body>
	<script>
	
	//5 min
time =  600000;
// Update the count down every 1 second
var x = setInterval(function() {
	
	   time = time - 1000;
	
	 var minutes = Math.floor((time % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((time % (1000 * 60)) / 1000);
	
    
    // Output the result in an element with id="demo"
   document.getElementById("demo").innerHTML =   minutes + "m " + seconds + "s ";
  
    // If the count down is over, write some text 
   /* if (time = 0) {
        
		
		
         
    }*/
	if(time < -500){
		document.getElementById("demo").innerHTML = "time up";
		clearInterval(x);
		document.getElementById("myBtn").click();
		
	}
}, 1000);
	
	
</script>
</html>