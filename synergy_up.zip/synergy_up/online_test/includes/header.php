<h1 style="text-align:center; font-family: Georgia">Synergy Academy of Science</h1>
    <h2 style="text-align:center">Online MCQ</h2>
<div class="row container">
   <div class="col-lg-4">
     <!-- subject button -->
      <h4>Select subject</h4>
       <button class="btn btn-primary" href="../physics.php">Physics</button>
       <button class="btn btn-success" href="../chemistery.php">Chemistry</button>
       <button class="btn btn-warning" href="../maths.php">Maths</button>
   </div>
   <div class="col-lg-4">
       <p> </p>
   </div>
   <div col-lg-4>
       <h4 class="text-right"><b>Time left: 63:12</b></h4>
   </div>
</div>
   <br>
