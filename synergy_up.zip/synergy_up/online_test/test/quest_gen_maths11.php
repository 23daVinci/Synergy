<?php 
if(isset($_POST['quest_gen'])){
	
    $subject = mysqli_real_escape_string($conn,$_POST['sub']);
	$quest = mysqli_real_escape_string($conn,$_POST['quest']);
	$opt1 = mysqli_real_escape_string($conn,$_POST['opt1']);
	$opt2 = mysqli_real_escape_string($conn,$_POST['opt2']);
	$opt3 = mysqli_real_escape_string($conn,$_POST['opt3']);
	$opt4 = mysqli_real_escape_string($conn,$_POST['opt4']);
    $correct_ans = mysqli_real_escape_string($conn,$_POST['cor_ans']);
    $chapter = mysqli_real_escape_string($conn,$_POST['chap']);
	if(empty($correct_ans)){
		$correct_ans = "";
	}elseif($correct_ans === "1"){
		$correct_ans = $opt1;
	}
	elseif($correct_ans === "2"){
		$correct_ans = $opt2;
	}elseif($correct_ans === "3"){
		$correct_ans = $opt3;
	}else{
		
	}

$query = "INSERT INTO `maths11` (`quest`, `correct_ans`, `opt_1`, `opt_2`, `opt_3`, `opt_4`, `chap`) VALUES ('$quest', '$correct_ans', '$opt1', '$opt2', '$opt3', '$opt4', '$chapter')";
$result = mysqli_query($conn,$query);
if(!$result){
	die(mysqli_error($conn));
}

}


?>




<h1 align="center">Maths</h1>
	<form action="" method="post">
	    <p>Subject</p>
	    <select name="sub" id="sub">
	        <option value="phy11">11th Physics</option>
	        <option value="chem11">11th Chemistry</option>
	    </select>
		<p>QUESTION</p>
		<input type="text" name="quest" id="quest"><br><br>
		<p>opt1</p>
		<input type="radio" name="cor_ans" id="cor_ans" value="1"><input type="text" name="opt1" id="opt1"><br><br>
		<p>opt2</p>
		<input type="radio" name="cor_ans" id="cor_ans" value="2"><input type="text" name="opt2" id="opt2"><br><br>
		<p>opt3</p>
		<input type="radio" name="cor_ans" id="cor_ans" value="3"><input type="text" name="opt3" id="opt3"><br><br>
		<p>opt4</p>
		<input type="radio" name="cor_ans" id="cor_ans" value="4"><input type="text" name="opt4" id="opt4"><br><br>
		<p>Chapter no</p>
		<input type="text" name="chap" placeholder="eg. 1, 2 etc">
		
		
		<button class="btn btn-success" type="submit" name="quest_gen">Submit</button>
		
		
	</form>
