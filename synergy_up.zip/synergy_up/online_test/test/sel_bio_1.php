<?php 
ob_start();
session_start();
$conn = mysqli_connect("127.0.0.1","root","","synergy");

if(mysqli_connect_error()){
	die(mysqli_error($conn));
}

		
if(isset($_POST['submit'])){
  

	$id = $_POST['checkBoxArray'];
	print_r($id);
	$_SESSION['quest'] = $id;
	print_r($_SESSION['quest']);

	
	//header("Location:quiz.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Select the quest</title>
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>

<body>
<br>
<br>
<div class="contanier">
	<div class="row">
	<div class="col-md-12">
<form action="" method="post">
		<table class="table table-hover text-center" >
		<thead>
			<tr>
				<th><input type="checkbox" id="selectAllBoxes" ></th>
				<th>Question</th>
				<th>Corect Ans</th>
				<th>Opt 1</th>
				<th>Opt 2</th>
				<th>Opt 3</th>
			</tr>
		</thead>
		<tbody>
		<?php 
			
			$query = "select * from quest";
			$select = mysqli_query($conn,$query);
			if(!$select){
				die("something went wrong " .mysqli_error($conn));
			}
			$quest_array = array("");
			while($row = mysqli_fetch_array($select)){
			$id = $row['quest_id'];
				
			$quest = substr($row['quest'],0,35)."...";
			$corr_ans = $row['correct_ans'];
			$opt1 = $row['opt_1'];
			$opt2 = $row['opt_2'];
			$opt3 = $row['opt_3'];
				
			echo "<tr>";
			echo "<td><input type='checkbox' name='checkBoxArray[]' value='$id ' class='checkBoxes'></td>";
			
			echo "<td>$quest</td>";
			echo "<td>$corr_ans</td>";
			echo "<td>$opt1</td>";
			echo "<td>$opt2</td>";
			echo "<td>$opt3</td>";
			echo "</tr>";
			}
			?>
		</tbody>
	</table>
	
	
	<button type="submit" name="submit">Submit</button>
	</form>
	</div>
	</div>
	 </div>

	 <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<script>
	$(document).ready(function(){

	$('#selectAllBoxes').click(function(event){
			
		if(this.checked ){
		$('.checkBoxes').each(function(){
			this.checked = true;
		});
		}
	 else{
		 $('.checkBoxes').each(function(){
			this.checked = false;
		});
	 	}
							   
});
 });
	
	</script>
</body>
</html>