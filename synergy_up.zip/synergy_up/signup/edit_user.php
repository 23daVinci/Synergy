<!DOCTYPE html>
<html lang="en">
<head>
<title>Synergy</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Unicat project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="../styles/bootstrap4/bootstrap.min.css">
<link href="../plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="../plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="../plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="../plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="../styles/main_styles.css">
<link rel="stylesheet" type="text/css" href="../styles/responsive.css">
	</head>
	<body>
	
	

<?php
		ob_start();
include("../includes/function.php");
include("../includes/db_conn.php");

if(isset($_GET['edit'])){
	$id = $_GET['edit'];
	
	
	
	$query = "select * from signup where student_id = $id";
	$select_query = mysqli_query($conn,$query);
	
	if(!$select_query){
		die("something went wrong plz try again " .mysqli_error($conn));
	}
	
	while($row = mysqli_fetch_array($select_query)){
		$fname = $row['fname'];
		$lname = $row['lname'];
		$dob = $row['dob'];
		$father_name = $row['father_name'];
		$mother_name = $row['mother_name'];
		$father_occ = $row['father_occ'];
		$school = $row['school'];
		$school_board = $row['school_board'];
		$present_school = $row['present_school'];
		$present_school_board = $row['present_school_board'];
		$stud_phone = $row['stud_phone'];
		$par_phone = $row['par_phone'];
		$stud_email = $row['stud_email'];
		$par_email = $row['par_email'];
		$address = $row['address'];
		$roll_no = $row['roll_no'];
		$course = $row['course'];
		$class = $row['class'];
		
		
	}
	
	
	

}
?>

      <div class="container">
      	<div class="row">
<section class="text-center">
    <h1>EDIT</h1>
    
    
    
    
    
    
    <form action="" autocomplete="off" method="post" role="form" enctype="multipart/form-data" >
		<div class="form-group ">
			<label for="firstname">Firstname</label>
			<input type="text" name="fname" class="form-control" value="<?php echo $fname;?>" required>
		</div>
	   
		<div class="form-group">
			<label for="lastname">Lastname</label>
			<input type="text" name="lname" class="form-control" value="<?php echo $lname;?>" required>
		</div>
   
	   <div class="form-group">
			<label for="dob">Date of Birth</label>
			<input type="date" name="dob" class="form-control" 
			value="<?php echo strftime('%Y-%m-%d', strtotime($dob));?>" required>
		</div>
	   
	
	 <!--  <div class="form-group">
			<label for="pic">Upload a Photo </label>
			<input type="file" name="image" class="form-control"  required>
		</div>-->

	   <div class="form-group">
			<label for="father_name">Father's name</label>
			<input type="text" name="father_name" class="form-control" value="<?php echo $father_name;?>" required>
		</div>
		
		<div class="form-group">
			<label for="mother_name">Mother's name</label>
			<input type="text" name="mother_name" class="form-control" value="<?php echo $mother_name;?>" required>
		</div>
		
		<div class="form-group">
			<label for="father_occ">Father's Occupation</label>
			<input type="text" name="father_occ" class="form-control" value="<?php echo $father_occ;?>"  required>
		</div>
				
		<div class="form-group">
			<label for="address">Residential Address</label>
			<textarea type="text" name="address" class="form-control"  rows="3" required >
				
				<?php echo $address;?>
			</textarea>
		</div>
				
				
		<div class="form-group">
			<label for="stud_phone">Student's Phone No</label>
			<input type="text" name="stud_phone" class="form-control" value="<?php echo $stud_phone;?>" required>
		</div>
		
		<div class="form-group">
			<label for="par_phone">Parent's Phone No</label>
			<input type="text" name="par_phone" class="form-control" value="<?php echo $par_phone;?>" required>
		</div>
					
		<div class="form-group">
			<label for="stud_email">Student's Email</label>
			<input type="email" name="stud_email" class="form-control" value="<?php echo $stud_email;?>" required>
		</div>
		
		<div class="form-group">
			<label for="par_email">Parent's Email</label>
			<input type="email" name="par_email" class="form-control" value="<?php echo $par_email;?>"  required>
		</div>
		
		
		<div class="form-group">
			<label for="school">School <span class="text-muted"> (Apperad in 10th standard)</span></label>
			<textarea type="text" name="school" class="form-control"   rows="3" required>
				<?php echo $school;?>
			</textarea>
		</div>
		
		<div class="form-group">
			<label for="school">Board
				<select name="school_board" id="school_board" class="form-control " >
				
				<?php
					switch($school_board){
						case "ssc":
							echo "<option value='ssc'>SSC</option>";
							echo "<option value='cbsc'>CBSC</option>";
							echo "<option value='icse'>ICSE</option>";
							echo "<option value='igcse'>IGCSE</option>";
							echo "<option value='other'>other</option>";
							break;
						case "cbsc":
							
							echo "<option value='cbsc'>CBSC</option>";
							echo "<option value='ssc'>SSC</option>";
							echo "<option value='icse'>ICSE</option>";
							echo "<option value='igcse'>IGCSE</option>";
							echo "<option value='other'>other</option>";
							break;
							
						case "icse":
						
							echo "<option value='icse'>ICSE</option>";
							echo "<option value='cbsc'>CBSC</option>";
							echo "<option value='ssc'>SSC</option>";
							echo "<option value='igcse'>IGCSE</option>";
							echo "<option value='other'>other</option>";
							break;
							
						case "IGCSE":
							

							echo "<option value='igcse'>IGCSE</option>";
							echo "<option value='other'>other</option>";
							echo "<option value='cbsc'>CBSC</option>";
							echo "<option value='ssc'>SSC</option>";
							echo "<option value='icse'>ICSE</option>";
							break;
							
						case "other":
							
							echo "<option value='other'>other</option>";
							echo "<option value='cbsc'>CBSC</option>";
							echo "<option value='ssc'>SSC</option>";
							echo "<option value='icse'>ICSE</option>";
							echo "<option value='igcse'>IGCSE</option>";
							break;
							
		
				
					
					}
					
					?>
					
				</select>
			</label>
		</div>
		
		<div class="form-group">
			<label for="present_school">Present School <span class="text-muted"> (Apperad in 12th standard if any)</span></label>
			<textarea type="text" name="present_school" class="form-control"   rows="3" id="present_school" >
				<?php echo $present_school[0];?>
			</textarea>
		</div>


			<div class="form-group">
			<label for="present_school_board">Present Board
				<select name="present_school_board" id="present_school_board" class="form-control " >
							
				<?php
					switch($present_school_board){
						case "hsc":
							echo '<option value="hsc">HSC</option>';
							echo '<option value="cbse">CBSE</option>';
							echo '<option value="isc">ISC</option>';
							echo '<option value="other">other</option>';
							break;
						case "cbse":
							
							echo '<option value="cbse">CBSE</option>';
							echo '<option value="hsc">HSC</option>';
							echo '<option value="isc">ISC</option>';
							echo '<option value="other">other</option>';
							break;
							
						case "isc":
							
							echo '<option value="isc">ISC</option>';
							echo '<option value="cbse">CBSE</option>';
							echo '<option value="hsc">HSC</option>';
							echo '<option value="other">other</option>';
							break;
							
						case "other":
							
							echo '<option value="other">other</option>';
							echo '<option value="cbse">CBSE</option>';
							echo '<option value="hsc">HSC</option>';
							echo '<option value="isc">ISC</option>';
							
							break;
							
						
							
		
				
					
					}
					
					?>
				</select>
			</label>
		</div>
		
		
		<div class="form-group">
			<label for="roll_no">Roll No.</label>
			<input type="text" name="roll_no" class="form-control" value="<?php echo $roll_no; ?>"  >
		</div>
		
		
		<div class="form-group">
			<label for="course">Course</label>
			<input type="text" name="course" class="form-control" value="<?php echo $course; ?>"  >
		</div>
		
		<div class="form-group">
			<label for="class">Class</label>
			<input type="text" name="class" class="form-control" value="<?php echo $class; ?>"  >
		</div>
		

		
		

		<!--<div class="form-group">
			<label for="user_password">Password</label>
			<input type="password" id="password" name="password" class="form-control" required>
		</div>
		
		<div class="form-group">
			<label for="user_cnf_password">Conform Password</label>
			<input type="password" id="cnf_password" name="cnf_password" class="form-control" required>
			
		</div>-->
		<!--
			<div class="hide invisible">
            	 Password length should be greater than 8
			</div>-->
   
   		<div class="form-group">
			<button type="submit"  name="edit_id"  id="edit_id" class="btn btn-primary ">Edit</button>
		</div>
    </form>
    
    
 </section>
   </div>
      </div>     
    
	
    
<?php 
if(isset($_POST['edit_id'])){
	
	$fname = string_check($_POST['fname']);
	$lname = string_check($_POST['lname']);
	$dob = string_check($_POST['dob']);
	$father_name = string_check($_POST['father_name']);
	$mother_name = string_check($_POST['mother_name']);
	$father_occ = string_check($_POST['father_occ']);
	$school = string_check($_POST['school']);
	$school_board = string_check($_POST['school_board']);
	$present_school = string_check($_POST['present_school']);
	$present_school_board = string_check($_POST['present_school_board']);
	$stud_phone = string_check($_POST['stud_phone']);
	$par_phone = string_check($_POST['par_phone']);
	$stud_email = string_check($_POST['stud_email']);
	$par_email = string_check($_POST['par_email']);
	$address = string_check($_POST['address']);
	$roll_no = string_check($_POST['roll_no']);
	$course = string_check($_POST['course']);
	$class = string_check($_POST['class']);
	$password = $roll_no;
	
	$password = password_hash($password,PASSWORD_BCRYPT,array('cost'=>10));

	
	

$query = "UPDATE `signup` SET  
 `fname` = '$fname' , `lname` = '$lname' , `dob` = '$dob', `father_name` = '$father_name', `mother_name` = '$mother_name', `father_occ` = '$father_occ', `school` = '$school', `school_board` = '$school_board', `present_school` = '$present_school', `present_school_board` = '$present_school_board', `stud_phone` = '$stud_phone' , `par_phone` = '$par_phone', `stud_email` = '$stud_email', `par_email` = '$par_email', `address` = '$address',
 `roll_no` = '$roll_no' ,  `password` = '$password',`course` = '$course',`class` = '$class'
 
 WHERE `signup`.`student_id` = $id;";
	
	
$create_student_query = mysqli_query($conn,$query);


}

?>
	
	<script src="../../styles/bootstrap4/bootstrap.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="../../styles/jquery.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="../../styles/bootstrap4/popper.js"  integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
	

</body>
</html>