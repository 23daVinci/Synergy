<!DOCTYPE html>
<html lang="en">
<head>
<title>Synergy</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Unicat project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="../styles/bootstrap4/bootstrap.min.css">
<link href="../plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="../plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="../plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="../plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="../styles/main_styles.css">
<link rel="stylesheet" type="text/css" href="../styles/responsive.css">
	</head>
	
	<?php
include("../includes/function.php");
include("../includes/db_conn.php");
	
		
	
	
	?>
	
<body>

<h3 style="text-align:center;">List of all the users</h3>
<br>
	<div class="container-fluid">
		<div class="row">
			<table class="table table-hover table-bordered">
				<thead >
					<th>Name</th>
					<th>DOB</th>
					<th>School</th>
					<th>Present School</th>
					<th>Student Phone</th>
					<th>Parent Phone</th>
					<th>Student email</th>
					<th>Parent Email</th>
					<th>Edit</th>
					<th>Delete</th>
				</thead>
				<tbody class="table ">
					
					<?php 
						$query = "select * from signup";
						$result = mysqli_query($conn,$query);
						if(!$result){
							die("something went wrong ".mysqli_error($conn));
						}
						while($row = mysqli_fetch_array($result)){
							$id = $row['roll_no'];
							$name = $row['fname'] ." ".$row['lname'];
							$dob = $row['dob'];
							$dob = strftime('%d-%m-%Y', strtotime($dob));
							$school = substr($row['school'],0,20);
							$present_school = substr($row['present_school'],0,20);
							$stud_phone = $row['stud_phone'];
							$par_phone = $row['par_phone'];
							$stud_email = $row['stud_email'];
							$par_email = $row['par_email'];
						
						
					
					echo "<tr>";
					echo "<td>$name</td>";
					echo "<td>$dob</td>";
					echo "<td>$school</td>";
					echo "<td>$present_school</td>";
					echo "<td>$stud_phone</td>";
					echo "<td>$par_phone</td>";
					echo "<td>$stud_email</td>";
					echo "<td>$par_email</td>";
					echo "<td><a href='edit_user.php?edit={$id}'>EDIT</a></td>";
					echo "<td><a href='all_users.php?delete={$id}'>DELETE</a></td>";
					echo "</tr>";
							 }?>
				</tbody>
			</table>
			
           <!--<?php echo strftime('%Y-%m-%d', strtotime($dob));?>-->
			
		</div><!--row-->
	</div><!--container-->



<?php 
	if(isset($_GET['delete'])){
			 
			 $id=$_GET['delete'];
			 $query ="delete from signup where student_id ={$id} ";
			 $delete_query = mysqli_query($conn,$query);
			 header("Location: all_users.php ");
			  if(!$delete_query){
				  die(mysqli_error($conn));
			  }
		 }
	
	
?>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="js/custom.js"></script>
</body>
</html>