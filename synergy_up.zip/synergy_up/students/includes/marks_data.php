<?php session_start();
        
include("../includes/db_conn.php");
include("../includes/function.php");


if(isset($_POST['display_marks'])){
	
     $roll_no = $_SESSION['roll_no'];
   
    
     $query = "SELECT * FROM marks WHERE roll_no = $roll_no";
    	$select_query = mysqli_query($conn,$query);
	
	query_check($select_query);
    ?>
    <div class="form-group row">
	<table class="table">
			<thead>
				<tr>
					<th>Roll no</th>
					<th>Test date</th>
					<th>Sub 1</th>
					<th>Sub 2</th>
					<th>Sub 3</th>
					<th>Sub 4</th>
				</tr>
			</thead>
			<tbody>
				
<?php
	while($row = mysqli_fetch_array($select_query)){ 
        $roll_no = $row['roll_no'];
        $test_date = $row['test_date'];
		$sub1 = $row['sub1'];
		$sub2 = $row['sub2'];
		$sub3 = $row['sub3'];
		$sub4 = $row['sub4'];
		
		echo "<tr>";
		echo "<td>  $roll_no</td>";
		echo "<td>  $test_date</td>";
		echo "<td>  $sub1 </td>";
		echo "<td>  $sub2 </td>";
		echo "<td>  $sub3 </td>";
		echo "<td>  $sub4 </td>";
		echo "</tr";	
		
					
					
		?>
   				
			</tbody>
			<?php } /*while*/ ?> 
		</table>
</div>
		

<?php	}  /*isset*/ ?>
   
   
  

