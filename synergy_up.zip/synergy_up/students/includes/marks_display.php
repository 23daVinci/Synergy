<?php
   if(isset($_POST['display_marks'])){
   $test = $_POST['mtest'];
   $roll_no = $_SESSION['roll_no'];
   
   $query = "SELECT * FROM marks WHERE test = '". $test."' AND roll_no=".$roll_no;
   $result = mysqli_query($conn, $query);
	if(!$result){
		die(mysqli_error($conn));
	}
	else{

   while($row = mysqli_fetch_array($result))
            { ?>
 						
 						    <tbody>
 						        <tr>
                                    <?php echo "<td>" . $row['test_date'] . "</td>"; ?>
 						            <?php echo "<td>" . $row['sub1'] . "</td>"; ?>
 						            <?php echo "<td>" . $row['sub2'] . "</td>"; ?>
 						            <?php echo "<td>" . $row['sub3'] . "</td>"; ?>
 						            <?php echo "<td>" . $row['sub4'] . "</td>"; ?>
 						        </tr>
 						    </tbody>
 						
 						<?php } ?>
   <?php }
   
      mysqli_close($conn);
   }
    ?>