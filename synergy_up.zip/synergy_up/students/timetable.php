
<!DOCTYPE html>
<html lang="en">
<head>
<title>Synergy</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Unicat project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="../styles/bootstrap4/bootstrap.min.css">
<link href="../plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="../plugins/colorbox/colorbox.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="../plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="../plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="../plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="../styles/course.css">
<link rel="stylesheet" type="text/css" href="../styles/course_responsive.css">
</head>
<body>

<div class="super_container">

	<!-- Header -->

	<header class="header">
			
	<!-- Top Bar -->
		<div class="top_bar" style="background-color: #cc9a5e">
			<div class="top_bar_container">
				<div class="container">
					<div class="row">
						<div class="col">
							<div class="top_bar_content d-flex flex-row align-items-center justify-content-start">
								<ul class="top_bar_contact_list">
								<li><a href="profile.php"><button class="btn btn-success">Profile</button></a></li>
								</ul>
								<div class="top_bar_login ml-auto">
									<div class="login_button"><a href="../login/logout.php">Logout</a></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>				
		</div>

		<!-- Header Content -->
		<div class="header_container" style="background-color: #292929">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="header_content d-flex flex-row align-items-center justify-content-start">
							<div class="logo_container">
								<a href="#">
									<div class="logo_text" style="color: white">S<span style="color:#d8731a">y</span>nerg<span style="color:#d8731a">y</span></div>
								</a>
							</div>

						</div>
					</div>
				</div>
			</div>
		</div>


		<!-- Header Search Panel -->
		<div class="header_search_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="header_search_content d-flex flex-row align-items-center justify-content-end">
							<form action="#" class="header_search_form">
								<input type="search" class="search_input" placeholder="Search" required="required">
								<button class="header_search_button d-flex flex-column align-items-center justify-content-center">
									<i class="fa fa-search" aria-hidden="true"></i>
								</button>
							</form>
						</div>
					</div>
				</div>
			</div>			
		</div>			
	</header>

	<!-- Menu -->

	<div class="menu d-flex flex-column align-items-end justify-content-start text-right menu_mm trans_400">
		<div class="menu_close_container"><div class="menu_close"><div></div><div></div></div></div>
		<div class="search">
			<form action="#" class="header_search_form menu_mm">
				<input type="search" class="search_input menu_mm" placeholder="Search" required="required">
				<button class="header_search_button d-flex flex-column align-items-center justify-content-center menu_mm">
					<i class="fa fa-search menu_mm" aria-hidden="true"></i>
				</button>
			</form>
		</div>
		<nav class="menu_nav">
			<ul class="menu_mm">
				<li class="menu_mm"><a href="index.html">Home</a></li>
				<li class="menu_mm"><a href="#">About</a></li>
				<li class="menu_mm"><a href="#">Courses</a></li>
				<li class="menu_mm"><a href="#">Blog</a></li>
				<li class="menu_mm"><a href="#">Page</a></li>
				<li class="menu_mm"><a href="contact.html">Contact</a></li>
			</ul>
		</nav>
	</div>
	
	<!-- Home -->

	<div class="home">
		<div class="breadcrumbs_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="breadcrumbs">
							<ul>
								<li><a href="">Home</a></li>
								<li><a href="">login</a></li>
                                <li><a href="">Student's profile</a></li>
                                <li><a href="">check marks</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>			
	</div>
        
 <!-- Timetable -->
<br>
<br>
<br>
<br>
    <table border="3" class="table" cellpadding="5" align ="center" width="100%">
<tr> 
	<th colspan="9">
		<h1>Time Table </h1>
		
	</th>
</tr>
<tr>
<th>Slot</th>
<th>Mon</th>
<th>Tue</th>
<th>Wed</th>
<th>Thur</th>
<th>Fri</th>
<th>Sat</th>

</tr>

<?php
$db['db_host']="localhost";
	$db['db_user']="root";
	$db['db_pass']="";
	$db['db_name']="synergy";

	foreach($db as $key => $value){
		define(strtoupper($key),$value);

	}
	$conn = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);

 if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$query = "SELECT * FROM `timetable`";
$select_query = mysqli_query($conn,$query);

if(!$select_query){
	die(mysqli_error($conn));
}

while($row = mysqli_fetch_array($select_query)){
	$mon_slot1 = $row['mon_slot1'];
    $mon_slot2 = $row['mon_slot2'];
    $mon_slot3 = $row['mon_slot3'];
    $mon_slot4 = $row['mon_slot4'];
    $mon_slot5 = $row['mon_slot5'];
    
    $tue_slot1 = $row['tue_slot1'];
    $tue_slot2 = $row['tue_slot2'];
    $tue_slot3 = $row['tue_slot3'];
    $tue_slot4 = $row['tue_slot4'];
    $tue_slot5 = $row['tue_slot5'];
    
    $wed_slot1 = $row['wed_slot1'];
    $wed_slot2 = $row['wed_slot2'];
    $wed_slot3 = $row['wed_slot3'];
    $wed_slot4 = $row['wed_slot4'];
    $wed_slot5 = $row['wed_slot5'];
    
    $thu_slot1 = $row['thu_slot1'];
    $thu_slot2 = $row['thu_slot2'];
    $thu_slot3 = $row['thu_slot3'];
    $thu_slot4 = $row['thu_slot4'];
    $thu_slot5 = $row['thu_slot5'];
    
    $fri_slot1 = $row['fri_slot1'];
    $fri_slot2 = $row['fri_slot2'];
    $fri_slot3 = $row['fri_slot3'];
    $fri_slot4 = $row['fri_slot4'];
    $fri_slot5 = $row['fri_slot5'];
   
    $sat_slot1 = $row['sat_slot1'];
    $sat_slot2 = $row['sat_slot2'];
    $sat_slot3 = $row['sat_slot3'];
    $sat_slot4 = $row['sat_slot4'];
    $sat_slot5 = $row['sat_slot5'];


echo "<tr>";
echo "<th>Slot 1</th>";

echo "<td>$mon_slot1</td>";
echo "<td>$tue_slot1 </td>";
echo "<td>$wed_slot1</td>";
echo "<td>$thu_slot1</td>";
echo "<td>$fri_slot1</td>";
echo "<td>$sat_slot1</td>";
echo "</tr>";
    
echo "<tr>";
echo "<th>Slot 2</th>";

echo "<td>$mon_slot2</td>";
echo "<td>$tue_slot2 </td>";
echo "<td>$wed_slot2</td>";
echo "<td>$thu_slot2</td>";
echo "<td>$fri_slot2</td>";
echo "<td>$sat_slot2</td>";
echo "</tr>";
    
echo "<tr>";
echo "<th>Slot 3</th>";

echo "<td>$mon_slot3</td>";
echo "<td>$tue_slot3 </td>";
echo "<td>$wed_slot3</td>";
echo "<td>$thu_slot3</td>";
echo "<td>$fri_slot3</td>";
echo "<td>$sat_slot3</td>";
echo "</tr>";

echo "<tr>";
echo "<th>Slot 4</th>";

echo "<td>$mon_slot4</td>";
echo "<td>$tue_slot4 </td>";
echo "<td>$wed_slot4</td>";
echo "<td>$thu_slot4</td>";
echo "<td>$fri_slot4</td>";
echo "<td>$sat_slot4</td>";
echo "</tr>";
    
echo "<tr>";
echo "<th>Slot 5</th>";

echo "<td>$mon_slot5</td>";
echo "<td>$tue_slot5</td>";
echo "<td>$wed_slot5</td>";
echo "<td>$thu_slot5</td>";
echo "<td>$fri_slot5</td>";
echo "<td>$sat_slot5</td>";
echo "</tr>";
?>

<?php }?>

	
</table>    
<br>    
<br>    
<br>    
<br>    
<br>    

<!-- Footer -->

	<footer class="footer" style="background-color: #141313">
		<div class="footer_background" style="background-image:url(../images/footer_background.png)"></div>
		<div class="container">
			<div class="row footer_row">
				<div class="col">
					<div class="footer_content">
						<div class="row">

							<div class="col-lg-3 footer_col">
					
								<!-- Footer About -->
								<div class="footer_section footer_about">
									<div class="footer_logo_container">
										<a href="#">
											<div class="footer_logo_text">S<span style="color: #d8731a">y</span>nerg<span style="color: #d8731a">y</span></div>
											<br>
											<h4 style="color: white">academy of science</h4>
										</a>
									</div>
									<div class="footer_about_text">
										<p>Lorem ipsum dolor sit ametium, consectetur adipiscing elit.</p>
									</div>
									<div class="footer_social">
										<ul>
											<li><a href="https://www.facebook.com/synergyacademyofscience/"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
											<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
											<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
										</ul>
									</div>
								</div>
								
							</div>

							<div class="col-lg-3 footer_col">
					
								<!-- Footer Contact -->
								<div class="footer_section footer_contact">
									<div class="footer_title" style="color: #d8731a">Contact Us</div>
									<div class="footer_contact_info">
										<ul>
											<li>Email: Info.deercreative@gmail.com</li>
											<li>Phone:  +(88) 111 555 666</li>
											<li>40 Baria Sreet 133/2 New York City, United States</li>
										</ul>
									</div>
								</div>
								
							</div>

							<div class="col-lg-3 footer_col">
					
								
							</div>

							<div class="col-lg-3 footer_col clearfix">
					
								
							</div>

						</div>
					</div>
				</div>
			</div>

			<div class="row copyright_row">
				<div class="col">
					<div class="copyright d-flex flex-lg-row flex-column align-items-center justify-content-start">
						
					</div>
				</div>
			</div>
		</div>
	</footer>
</div>

<script src="../js/jquery-3.2.1.min.js"></script>
<script src="../styles/bootstrap4/popper.js"></script>
<script src="../styles/bootstrap4/bootstrap.min.js"></script>
<script src="../plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="../plugins/easing/easing.js"></script>
<script src="../plugins/parallax-js-master/parallax.min.js"></script>
<script src="../plugins/colorbox/jquery.colorbox-min.js"></script>
<script src="../js/course.js"></script>
</body>
</html>